# المرحلة الثالثة - Firebase Ingestion API

تمت إضافة Firebase Cloud Function باسم `ingestJob`.

وظيفتها:
1. استقبال إعلان من لوحة الإدارة.
2. التأكد من وجود مستخدم Firebase مسجل الدخول.
3. إنشاء duplicateKey.
4. فحص `jobs` و`pending_jobs`.
5. منع التكرار.
6. حفظ الإعلان الجديد في `pending_jobs` فقط، وليس نشره مباشرة.
7. تسجيل UID والبريد وطريقة الاستيراد ومصدر الإعلان.

تم ربط زر "إضافة للمسودة" في مستورد الإعلانات بالـ Cloud Function.

## النشر
من مجلد المشروع:
- `cd functions`
- `npm install`
- `firebase deploy --only functions:ingestJob`

أو من جذر المشروع:
- `firebase deploy --only functions:ingestJob`

ملاحظة: هذه المرحلة لا تسحب LinkedIn/Facebook/WUZZUF تلقائيا؛ هي API آمنة لاستقبال الإعلان الذي تم التحقق منه، ومنع تكراره، ووضعه في قائمة المراجعة.
