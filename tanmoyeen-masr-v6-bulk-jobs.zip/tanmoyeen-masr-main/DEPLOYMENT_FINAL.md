# تشغيل النسخة النهائية

1. ثبّت Firebase CLI وNode.js 20+.
2. نفذ: firebase login
3. نفذ: firebase use tanmoyeen-masr26
4. من مجلد functions: npm install
5. من جذر المشروع: firebase deploy --only functions
6. إذا كان Firebase Hosting مستخدما: firebase deploy --only hosting

Cloud Functions:
- ingestJob: استقبال الإعلان، فحص التكرار، وحفظه في pending_jobs للمراجعة.
- expireJobs: فحص يومي للوظائف وتحويل المنتهي منها إلى expired.

اختبار النظام:
استيراد إعلان → تحليل وفحص التكرار → إضافة للمسودة → مراجعة → نشر.
إعادة استيراد نفس الإعلان يجب أن تمنعه Firebase كتكرار.

ملاحظة: لا يوجد scraping مباشر داخل التطبيق من LinkedIn/Facebook/WUZZUF؛ يتم تمرير النص/JSON والرابط الأصلي إلى النظام، ويمكن إضافة APIs رسمية للمصادر التي تسمح بذلك.
