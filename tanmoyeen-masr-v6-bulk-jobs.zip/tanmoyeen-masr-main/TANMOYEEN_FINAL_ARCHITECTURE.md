# البنية النهائية

مصادر الإعلانات
→ بحث والتحقق
→ مستورد الإعلان
→ Firebase ingestJob
→ فحص التكرار
→ pending_jobs
→ مراجعة الإدارة
→ jobs
→ التطبيق
→ الإشعارات

الحقول الأساسية:
title, org, gov, type, sec, sal, dl, contact, desc, link, source, duplicateKey, status, publishedAt, updatedAt

الحالات:
pending → approved → expired
duplicate = إعلان مكرر تم منعه

منع التكرار:
1. الرابط الأصلي بعد التطبيع
2. الجهة + المسمى + المحافظة + الموعد النهائي
